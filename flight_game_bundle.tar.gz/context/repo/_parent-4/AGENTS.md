# Mac/XC/MacBook AI Topology Contract

This is the unique maintenance source for every AI tool operating in the Mac/XC/MacBook
estate. It governs EasyTier, SSH, Hermes, SoulMirror, UUYC, remote desktop, node
pairing, collection, and recovery. Runtime-specific rules must link here rather
than duplicate or weaken this contract.

## Names and identity

- `Mac` or `Mac 端` means the Mac Mini authority at `10.126.126.1`.
- `XC`, `XC 端`, `XC 笔记本`, `XC 笔记本电脑`, `XC 电脑`, and `XC 节点` mean the
  portable Windows child node at `10.126.126.2`.
- `MacBook` means the portable macOS child node at `10.126.126.41`.
- `X1`, `LAPTOP-7UNJ4RMQ`, Windows account names, existing SSH alias `wqs`,
  configured node names, and legacy file names are compatibility identifiers
  only. Do not rename them as part of this terminology change, and do not use
  `X1` as the current architectural name in new rules, prompts, reports, or UI.

## Authority and layers

- Mac is the sole control plane, source of truth, and SoulMirror mother node.
  Only Mac runs `soulmirror start` and owns the daemon, wiki, node registry,
  pairing, collection orchestration, and authoritative data.
- XC and MacBook are mobile workbenches, execution planes, and already-paired
  SoulMirror child nodes. They may only run `soulmirror node`; they must never
  run another daemon, wiki, registry, pairing center, bootstrap path, or parallel
  mainbrain.
- EasyTier is the private transport plane. SSH is the bidirectional command
  plane for all child nodes (`XC -> Mac: ssh ted`; `Mac -> XC: ssh wqs`;
  `MacBook -> Mac: ssh ted`; `Mac -> MacBook: ssh torus`). UUYC is interaction only.
  The Alibaba Cloud ECS (`47.116.105.165`, EasyTier `10.126.126.4`) acts only as
  a private EasyTier/FRP relay for IPv4 fallback and proxy jump; it must not run
  SoulMirror control plane or替代 Mac authority.
  Do not create another VPN, tunnel, key, port-forward, remote desktop, or public
  exposure.

## EasyTier access control

The following access matrix is enforced on the EasyTier plane (`10.126.126.0/24`):

| Source | Destination | Status | Notes |
|--------|-------------|--------|-------|
| XC (`10.126.126.2`) | Mac (`10.126.126.1`) | ✅ allowed | SSH alias `ted` |
| XC (`10.126.126.2`) | VPS (`10.126.126.3`) | ✅ allowed | XC workbench to VPS services |
| XC (`10.126.126.2`) | ECS (`10.126.126.4`) | ✅ allowed | XC workbench to ECS relay |
| MacBook (`10.126.126.41`) | Mac (`10.126.126.1`) | ✅ allowed | SSH alias `torus` / `macbook` |
| MacBook (`10.126.126.41`) | VPS (`10.126.126.3`) | ✅ allowed | MacBook workbench to VPS services |
| MacBook (`10.126.126.41`) | ECS (`10.126.126.4`) | ✅ allowed | MacBook workbench to ECS relay |
| Phone (`10.126.126.5`) | Mac / VPS / ECS | ✅ allowed | Mobile control interface |
| Glasses (`10.126.126.6`) | Mac / VPS / ECS | ✅ allowed | AR control interface |
| Mac (`10.126.126.1`) | XC / VPS / ECS / Phone / Glasses | ✅ allowed | Control plane to all child nodes |
| VPS (`10.126.126.3`) | ECS (`10.126.126.4`) | ✅ allowed | Infrastructure peering only |
| ECS (`10.126.126.4`) | VPS (`10.126.126.3`) | ✅ allowed | Infrastructure peering only |
| VPS (`10.126.126.3`) | Mac / XC / MacBook / Phone / Glasses | ❌ blocked | VPS cannot initiate to child nodes |
| ECS (`10.126.126.4`) | Mac / XC / MacBook / Phone / Glasses | ❌ blocked | ECS cannot initiate to child nodes |

Enforcement: on both the VPS and the ECS, iptables `OUTPUT` rules on interface
`tun0` drop `NEW`-state packets destined for `10.126.126.1`, `10.126.126.2`, `10.126.126.41`,
`10.126.126.5` and `10.126.126.6`. Return traffic for sessions initiated by
Mac, XC, MacBook, Phone or Glasses remains allowed, including an explicit rule that
permits ICMP echo replies out `tun0`. On VPS (Debian/Ubuntu), rules are persisted in
`/etc/iptables/rules.v4` and loaded by `netfilter-persistent`. On ECS (Alibaba Cloud Linux/RHEL),
rules are persisted in `/etc/sysconfig/iptables` and loaded by the `iptables` service.

Do not weaken these rules or create alternate paths that let the VPS reach Mac
or XC.

**Reverse entry policy**: the only allowed reverse entry from the public IPv4
Internet into Mac is the FRP tunnel initiated by Mac to ECS (`47.116.105.165:51322
-> Mac 127.0.0.1:51322`). Do not add additional SSH reverse tunnels, port
forwards, or remote desktop exposures on VPS, ECS, or any other node.

## Recovery discipline

- XC sleep, wake, lid close, or network switching restores the same topology; it
  never justifies rejoin, re-pair, re-initialization, or a replacement architecture.
- Wait for the existing EasyTier and node services to recover, then diagnose in
  order: Mac local health, EasyTier reachability, SSH, XC `soulmirror node`, then
  collectors. Make only minimal, reversible changes after a backup.
- Before every topology, config, task, skill, model, gateway, or daemon change,
  confirm an existing backup or create one. Verify service health and readable
  key files before declaring success.

## Invariants

- One Mac authority, one XC child node, one MacBook child node, one logical
  SoulMirror estate.
- Recovery restores connectivity and processes only; it never changes authority,
  identity, pairing, or topology.

## Browser policy

All Mac browser work must follow [`~/.agents/BROWSER_POLICY.md`](../.agents/BROWSER_POLICY.md).
Use the existing visible Chrome through CDP at `http://127.0.0.1:9222`; do not
launch a separate browser, use headless mode, or create another profile unless
the user explicitly approves the narrow offline-rendering exception in that policy.
